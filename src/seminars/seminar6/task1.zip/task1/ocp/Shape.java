package seminars.seminar6.task1.ocp;

public interface Shape {
    void draw ();
}
