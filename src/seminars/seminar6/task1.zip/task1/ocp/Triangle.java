package seminars.seminar6.task1.ocp;

public class Triangle implements Shape{

    @Override
    public void draw() {
        System.out.println("#");
        System.out.println("##");
        System.out.println("###");
        System.out.println();
    }
}
