package seminars.seminar6.task1.dip;

public interface Device {

    void turnOn();
    void turnOff();
    boolean getIsOn();
}
