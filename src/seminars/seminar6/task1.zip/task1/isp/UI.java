package seminars.seminar6.task1.isp;

public interface UI {
    int getWithdrawSum ();
    int getDepositSum ();
    int getTransferSum ();
    String getTransferTarget ();
}
