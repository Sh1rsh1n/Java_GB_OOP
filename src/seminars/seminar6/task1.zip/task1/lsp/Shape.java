package seminars.seminar6.task1.lsp;

public interface Shape {

    float getWidth();
    void setWidth(float width);
    float getHeight();
    void setHeight(float height);

    float getArea();

}
