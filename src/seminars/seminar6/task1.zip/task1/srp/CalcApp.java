package seminars.seminar6.task1.srp;

public class CalcApp {
    public static void main(String[] args) {
        CalcRectangle rect = new CalcRectangle(5, 5);
        System.out.format("Area = %d\n", rect.getArea());
    }
}
