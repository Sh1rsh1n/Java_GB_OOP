package seminars.seminar5.task1.controller;

public interface UserController {

    void showMenu();
}
