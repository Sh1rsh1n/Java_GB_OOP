package seminars.seminar5.task1.service;

import seminars.seminar5.task1.model.Teacher;

import java.util.List;

public class TeacherService implements DataService<Teacher> {

    @Override
    public List<Teacher> getUsers() {
        return null;
    }

    @Override
    public void addUser(Teacher user) {

    }

    @Override
    public void save() {

    }

    @Override
    public void load() {

    }
}
